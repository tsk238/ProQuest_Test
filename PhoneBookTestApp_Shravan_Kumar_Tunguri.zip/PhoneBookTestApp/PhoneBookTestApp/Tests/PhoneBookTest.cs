﻿using NUnit.Framework;

namespace PhoneBookTestAppTests
{
    // ReSharper disable InconsistentNaming

    [TestFixture]
    public class PhoneBookTest
    {
        [Test]
        public void addPerson()
        {

            Assert.Fail();
        }

        [Test]
        public void findPerson()
        {
            Assert.Fail();
        }
    }

    // ReSharper restore InconsistentNaming 
}
﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneBookTestApp
{
    class Program
    {
        static IPhoneBook phonebook = new PhoneBook();

        static void Main(string[] args)
        {
            try
            {               
                /* TODO: create person objects and put them in the PhoneBook and database
                * John Smith, (248) 123-4567, 1234 Sand Hill Dr, Royal Oak, MI
                * Cynthia Smith, (824) 128-8758, 875 Main St, Ann Arbor, MI
                */
               Program.CreatePhoneBookList();

               // TODO: print the phone book out to System.out
               var phoneBookList = phonebook.findPerson();
               Program.PrintPhoneBook(phoneBookList,"---Phone Book List---");

               // TODO: find Cynthia Smith and print out just her entry
               var phoneBookByNamelist = phonebook.findPerson("Cynthia Smith");
               Program.PrintPhoneBook(phoneBookByNamelist, "---Find person \"Cynthia Smith\" in Phone Book List---");

                // TODO: insert the new person objects into the database
                CreatePersonRecord("Shravan Tunguri", "(111) 222-3333", "1 Main St, Jersey City, NJ");

                // Print final Phone Book list
                var finalPhoneBookList = phonebook.findPerson();
                Program.PrintPhoneBook(finalPhoneBookList, "---Final Phone Book List---");

               // Console.Read();
            }
            finally
            {
                DatabaseUtil.CleanUp();
            }
        }

        static void PrintPhoneBook(List<IPerson> PhonebookList, string headerMessage)
        {
            Console.WriteLine(headerMessage);
            foreach (var person in PhonebookList)
            {
                Console.WriteLine("Name: {0} \t Phone Number:{1} \t Address:{2}", person.name, person.phoneNumber, person.address);
            }
            Console.WriteLine(Environment.NewLine);
        }

        static void CreatePhoneBookList()
        {
            CreatePersonRecord("John Smith", "(248) 123 - 4567", "1234 Sand Hill Dr, Royal Oak, MI");
            CreatePersonRecord("Cynthia Smith", "(824) 128-8758", "875 Main St, Ann Arbor, MI");
        }

        static void CreatePersonRecord(string _name,string _phoneNumber,string _address)
        {
            IPerson a = new Person() { name = _name, phoneNumber = _phoneNumber, address = _address };
            phonebook.addPerson(a);
        }

        
    }
}

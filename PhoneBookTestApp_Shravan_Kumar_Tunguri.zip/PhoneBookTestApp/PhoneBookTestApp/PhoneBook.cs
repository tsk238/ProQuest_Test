﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SQLite;
using System.Runtime.InteropServices;

namespace PhoneBookTestApp
{
    public class PhoneBook : IPhoneBook
    {
        public DatabaseUtil db;
        public PhoneBook()
        {
            db = DatabaseUtil.Instance;
        }

        public void addPerson(IPerson newPerson)
        {
            db.AddPhoneBook(newPerson);
        }

        public List<IPerson> findPerson(string name)
        {
           return db.GetPhoneBookList(name);
        }
                
    }
}
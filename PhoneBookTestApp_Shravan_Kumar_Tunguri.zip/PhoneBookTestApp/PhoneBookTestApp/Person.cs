﻿using System;

namespace PhoneBookTestApp
{
    public class Person : IPerson
    {
        public string address { get; set; }
        public string name { get; set; }
        public string phoneNumber { get; set; }
    }
}
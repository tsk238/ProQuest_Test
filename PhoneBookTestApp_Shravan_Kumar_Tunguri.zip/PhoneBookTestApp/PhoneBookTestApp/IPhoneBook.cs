﻿using System.Collections.Generic;

namespace PhoneBookTestApp
{
    public interface IPhoneBook
    {
        List<IPerson> findPerson(string name="");
        void addPerson(IPerson newPerson);
    }
}
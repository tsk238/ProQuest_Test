﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;

namespace PhoneBookTestApp
{
    public class DatabaseUtil 
    {
        private static DatabaseUtil _instance;
        private DatabaseUtil()
        {
        }

        public static DatabaseUtil Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance  = new DatabaseUtil();
                    initializeDatabase();
                }
                return _instance;
            }           
        }

        static SQLiteConnection dbConnection = new SQLiteConnection("Data Source=" + Environment.CurrentDirectory + "\\MyDatabase.sqlite;Version=3;");

        public static void initializeDatabase()
        {
            dbConnection.Open();
            try
            {
                SQLiteCommand command =
                    new SQLiteCommand(
                        "create table PHONEBOOK (NAME varchar(255), PHONENUMBER varchar(255), ADDRESS varchar(255))",
                        dbConnection);
                command.ExecuteNonQuery();
                dbConnection.Close();            
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                dbConnection.Close();
            }
}
        public static SQLiteConnection GetConnection()
        {
            dbConnection.Open();
            return dbConnection;
        }
        public static void CleanUp()
        {
            dbConnection.Open();
            try
            {
                SQLiteCommand command =
                    new SQLiteCommand(
                        "drop table PHONEBOOK",
                        dbConnection);
                command.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                dbConnection.Close();
            }
        }
        public void AddPhoneBook(IPerson newPerson)
        {
            dbConnection.Open();
            try
            {
                SQLiteCommand command = new SQLiteCommand(string.Format("INSERT INTO PHONEBOOK (NAME, PHONENUMBER, ADDRESS) VALUES(\"{0}\",\"{1}\",\"{2}\")",
                                                          newPerson.name, newPerson.phoneNumber, newPerson.address), dbConnection);

                command.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                dbConnection.Close();
            }
        }

        public List<IPerson> GetPhoneBookList(string name)
        {
            List<IPerson> ImportedFiles = new List<IPerson>();
            dbConnection.Open();
            try
            {                
                using (SQLiteCommand cmd = dbConnection.CreateCommand())
                {
                    cmd.CommandText = "select * from PHONEBOOK WHERE NAME LIKE @host";
                    cmd.Parameters.AddWithValue("@host", string.Format("%{0}%", string.IsNullOrEmpty(name)?"%":name));
                    SQLiteDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        ImportedFiles.Add(new Person() { name = Convert.ToString(reader["NAME"]), phoneNumber = Convert.ToString(reader["PHONENUMBER"]), address = Convert.ToString(reader["ADDRESS"]) });
                    }
                    return ImportedFiles;
                }               
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                dbConnection.Close();
            }
}
    }
}